using Microsoft.EntityFrameworkCore;
using SupdeCoMaster2022Shop.Models;
using Microsoft.AspNetCore.Identity;

var builder = WebApplication.CreateBuilder(args);
string strConnection = builder.Configuration.GetConnectionString("DbSqlServerConnectionString");


builder.Services.AddDbContext<AppSupdeCoDBContext>(options =>
    options.UseSqlServer(strConnection));;

builder.Services.AddDefaultIdentity<IdentityUser>(options => options.SignIn.RequireConfirmedAccount = true)
    .AddEntityFrameworkStores<AppSupdeCoDBContext>();;

//1 - Configure les services.v
builder.Services.AddControllersWithViews();
builder.Services.AddRazorPages();

//builder.Services.AddScoped<ICategoryRepository, MockCategoryRepository>();
builder.Services.AddScoped<ICategoryRepository, CategoryRepository>();
builder.Services.AddScoped<IProductRepository, MockProductRepository>();
builder.Services.AddScoped<IAvisRepository, AvisRepository>();



//builder.Services.AddControllers();


var app = builder.Build();

var env = app.Environment;

if (env.IsDevelopment())
{
   app.UseDeveloperExceptionPage();

}

app.UseHttpsRedirection();

app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.UseEndpoints(endpoints =>
{

    endpoints.MapControllerRoute(
            name: "default",
            pattern: "{controller=Produits}/{action=List}/{id?}");

    endpoints.MapRazorPages();
});






//app.MapGet("/", () => "Hello World!");

app.Run();
