﻿using Microsoft.AspNetCore.Mvc;

namespace SupdeCoMaster2022Shop.Controllers
{
    public class TestController : Controller
    {
        public string Index()
        {
            //return View();

            return "Controller = Test, Action = Index";
        }
    }
}
