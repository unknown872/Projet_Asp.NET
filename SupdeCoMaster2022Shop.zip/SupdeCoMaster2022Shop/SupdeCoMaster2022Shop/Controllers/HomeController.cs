﻿using Microsoft.AspNetCore.Mvc;

namespace SupdeCoMaster2022Shop.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public string Bonjour()
        {
            return "Bonjour de la salle de classe!";
        
        }
    }
}
