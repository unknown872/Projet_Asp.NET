﻿using Microsoft.AspNetCore.Mvc;
using SupdeCoMaster2022Shop.Models;

namespace SupdeCoMaster2022Shop.Controllers
{
    public class ProduitsController : Controller
    {
        private IProductRepository _productRepository;

        public ProduitsController(IProductRepository productRepository)
        {
            this._productRepository = productRepository;

        }

        public IActionResult List()
        {
            var produits = this._productRepository.AllProducts;


            return View(produits);
        }

        public IActionResult Details(int id)
        {
            var product = this._productRepository.GetProductById(id);

            if (product == null) return NotFound();

            return View(product);


        }
    }
}
