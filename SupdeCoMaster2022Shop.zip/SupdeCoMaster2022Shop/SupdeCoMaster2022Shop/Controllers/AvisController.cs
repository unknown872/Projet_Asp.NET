﻿using Microsoft.AspNetCore.Mvc;
using SupdeCoMaster2022Shop.Models;

namespace SupdeCoMaster2022Shop.Controllers
{
    public class AvisController : Controller
    {
        private IAvisRepository _repositoryAvis;
        public AvisController(IAvisRepository avisRepository)
        {
            this._repositoryAvis = avisRepository;

        }
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Add(Avis avis)
        {
            if (ModelState.IsValid)
            {
                this._repositoryAvis.AddAvis(avis);

                return RedirectToAction("List", "Avis");

            }
            return View();
        }

        public IActionResult List()
        {
            var lesAvis = this._repositoryAvis.GetAllAvis();

            return View(lesAvis);

        }
    }
}
