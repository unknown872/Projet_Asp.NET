﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace SupdeCoMaster2022Shop.Models
{
    public class AppSupdeCoDBContext : IdentityDbContext<IdentityUser>
    {
        public AppSupdeCoDBContext(DbContextOptions<AppSupdeCoDBContext> options) : base(options)
        {
        }

        public DbSet<Category> Categories { get; set; }

        public DbSet<Product> Produits { get; set; }

        public DbSet<Avis> Avis { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //seed categories
            var cat1 = new Category { CategoryId = 1, CategoryName = "Alicaments", Description = "Nos aliments choisis pour une meilleure santé" };
            var cat2 = new Category { CategoryId = 2, CategoryName = "Produits beauté/Hygiène", Description = "La beauté n'a pas de prix!" };
            var cat3 = new Category { CategoryId = 3, CategoryName = "Produits electroniques", Description = "Nos produits électroniques pour vous simplifier la vie" };
            modelBuilder.Entity<Category>().HasData(cat1);
            modelBuilder.Entity<Category>().HasData(cat2);
            modelBuilder.Entity<Category>().HasData(cat3);

            //Seed Products
            var p1 = new Product
            {
                ProductId = 1,
                Name = "Dentifrice Adulte",
                Price = 1000M,
                ShortDescription = "Patte dentifrice pour Adulte qualité premium Ipsum",
                LongDescription = "Icing carrot cake jelly-o cheesecake. Sweet roll marzipan marshmallow toffee brownie brownie candy tootsie roll. Chocolate cake gingerbread tootsie roll oat cake Product chocolate bar cookie dragée brownie. Lollipop cotton candy cake bear claw oat cake. Dragée candy canes dessert tart. Marzipan dragée gummies lollipop jujubes chocolate bar candy canes. Icing gingerbread chupa chups cotton candy cookie sweet icing bonbon gummies. Gummies lollipop brownie biscuit danish chocolate cake. Danish powder cookie macaroon chocolate donut tart. Carrot cake dragée croissant lemon drops liquorice lemon drops cookie lollipop toffee. Carrot cake carrot cake liquorice sugar plum topping bonbon Product muffin jujubes. Jelly pastry wafer tart caramels bear claw. Tiramisu tart Product cake danish lemon drops. Brownie cupcake dragée gummies.",
                CategoryId = 2,
                ImageUrl = "dentifrice_adulte.jfif",
                InStock = true,
                IsProductOfTheWeek = false,
                ImageThumbnailUrl = "dentifrice_adulte.jfif"
            };
            var p2 = new Product
            {
                ProductId = 2,
                Name = "Dentifrice enfant",
                Price = 700M,
                ShortDescription = "Les dents de vos enfants doivent êtres soignées!",
                LongDescription = "Icing carrot cake jelly-o cheesecake. Sweet roll marzipan marshmallow toffee brownie brownie candy tootsie roll. Chocolate cake gingerbread tootsie roll oat cake Product chocolate bar cookie dragée brownie. Lollipop cotton candy cake bear claw oat cake. Dragée candy canes dessert tart. Marzipan dragée gummies lollipop jujubes chocolate bar candy canes. Icing gingerbread chupa chups cotton candy cookie sweet icing bonbon gummies. Gummies lollipop brownie biscuit danish chocolate cake. Danish powder cookie macaroon chocolate donut tart. Carrot cake dragée croissant lemon drops liquorice lemon drops cookie lollipop toffee. Carrot cake carrot cake liquorice sugar plum topping bonbon Product muffin jujubes. Jelly pastry wafer tart caramels bear claw. Tiramisu tart Product cake danish lemon drops. Brownie cupcake dragée gummies.",
                CategoryId = 2,
                ImageUrl = "dentifrice_enfant.jfif",
                InStock = true,
                IsProductOfTheWeek = false,
                ImageThumbnailUrl = "dentifrice_enfant.jfif"
            };
            var p3 = new Product
            {
                ProductId = 3,
                Name = "Stevia: Sucre sans calorie",
                Price = 1500M,
                ShortDescription = "Sucre feuilles stevia naturelle sans calorie et pour les diabétiques",
                LongDescription = "Icing carrot cake jelly-o cheesecake. Sweet roll marzipan marshmallow toffee brownie brownie candy tootsie roll. Chocolate cake gingerbread tootsie roll oat cake Product chocolate bar cookie dragée brownie. Lollipop cotton candy cake bear claw oat cake. Dragée candy canes dessert tart. Marzipan dragée gummies lollipop jujubes chocolate bar candy canes. Icing gingerbread chupa chups cotton candy cookie sweet icing bonbon gummies. Gummies lollipop brownie biscuit danish chocolate cake. Danish powder cookie macaroon chocolate donut tart. Carrot cake dragée croissant lemon drops liquorice lemon drops cookie lollipop toffee. Carrot cake carrot cake liquorice sugar plum topping bonbon Product muffin jujubes. Jelly pastry wafer tart caramels bear claw. Tiramisu tart Product cake danish lemon drops. Brownie cupcake dragée gummies.",
                CategoryId = 1,
                ImageUrl = "sucre_stevia.jfif",
                InStock = true,
                IsProductOfTheWeek = false,
                ImageThumbnailUrl = "sucre_stevia.jfif"
            };

            var p4 = new Product
            {
                ProductId = 4,
                Name = "Thiouray Guewe VIP",
                Price = 2000M,
                ShortDescription = "Thiouraye Guewe VIP  ",
                LongDescription = "Icing carrot cake jelly-o cheesecake. Sweet roll marzipan marshmallow toffee brownie brownie candy tootsie roll. Chocolate cake gingerbread tootsie roll oat cake Product chocolate bar cookie dragée brownie. Lollipop cotton candy cake bear claw oat cake. Dragée candy canes dessert tart. Marzipan dragée gummies lollipop jujubes chocolate bar candy canes. Icing gingerbread chupa chups cotton candy cookie sweet icing bonbon gummies. Gummies lollipop brownie biscuit danish chocolate cake. Danish powder cookie macaroon chocolate donut tart. Carrot cake dragée croissant lemon drops liquorice lemon drops cookie lollipop toffee. Carrot cake carrot cake liquorice sugar plum topping bonbon Product muffin jujubes. Jelly pastry wafer tart caramels bear claw. Tiramisu tart Product cake danish lemon drops. Brownie cupcake dragée gummies.",
                CategoryId = 2,
                ImageUrl = "thiouray_Gewe_vip.jfif",
                InStock = true,
                IsProductOfTheWeek = true,
                ImageThumbnailUrl = "thiouray_Gewe_vip.jfif"
            };
            var p5 = new Product
            {
                ProductId = 5,
                Name = "Chapelet Electro",
                Price = 1000M,
                ShortDescription = "chapelet electronique",
                LongDescription = "Icing carrot cake jelly-o cheesecake. Sweet roll marzipan marshmallow toffee brownie brownie candy tootsie roll. Chocolate cake gingerbread tootsie roll oat cake Product chocolate bar cookie dragée brownie. Lollipop cotton candy cake bear claw oat cake. Dragée candy canes dessert tart. Marzipan dragée gummies lollipop jujubes chocolate bar candy canes. Icing gingerbread chupa chups cotton candy cookie sweet icing bonbon gummies. Gummies lollipop brownie biscuit danish chocolate cake. Danish powder cookie macaroon chocolate donut tart. Carrot cake dragée croissant lemon drops liquorice lemon drops cookie lollipop toffee. Carrot cake carrot cake liquorice sugar plum topping bonbon Product muffin jujubes. Jelly pastry wafer tart caramels bear claw. Tiramisu tart Product cake danish lemon drops. Brownie cupcake dragée gummies.",
                CategoryId = 3,
                ImageUrl = "chapelet_electro.jpg",
                InStock = true,
                IsProductOfTheWeek = true,
                ImageThumbnailUrl = "chapelet_electro.jpg"
            };

            modelBuilder.Entity<Product>().HasData(p1);
            modelBuilder.Entity<Product>().HasData(p2);
            modelBuilder.Entity<Product>().HasData(p3);
            modelBuilder.Entity<Product>().HasData(p4);
            modelBuilder.Entity<Product>().HasData(p5);

        }

    }
}
