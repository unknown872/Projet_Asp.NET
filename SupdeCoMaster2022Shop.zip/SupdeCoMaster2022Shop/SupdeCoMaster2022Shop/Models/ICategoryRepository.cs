﻿namespace SupdeCoMaster2022Shop.Models
{
    public interface ICategoryRepository
    {
        IEnumerable<Category> AllCategories { get; }

        public Category GetCategoryById(int id);
    }
}
