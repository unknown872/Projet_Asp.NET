﻿using System.ComponentModel.DataAnnotations.Schema;

namespace SupdeCoMaster2022Shop.Models
{
 
    //[Table("ma_categorie")]
    public class Category
    {
        public int CategoryId { get; set; }

        //[Column("nom_category")]
        public string CategoryName { get; set; }

        public string Description { get; set; }

        public List<Product> Produits { get; set; }
    }
}
