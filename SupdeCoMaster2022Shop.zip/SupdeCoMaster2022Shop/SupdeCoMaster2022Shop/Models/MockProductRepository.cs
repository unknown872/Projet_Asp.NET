﻿namespace SupdeCoMaster2022Shop.Models
{
    public class MockProductRepository : IProductRepository
    {
        private List<Product> _allProducts;
        private ICategoryRepository _categoryRepository;

        public MockProductRepository(ICategoryRepository categoryRepository)
        {
            //_allProducts = new List<Product>();

            this._categoryRepository = categoryRepository;

            var p1 = new Product { ProductId = 1, Name = "Dentifrice Adulte", Price = 1000M, ShortDescription = "Patte dentifrice pour Adulte qualité premium Ipsum", LongDescription = "Icing carrot cake jelly-o cheesecake. Sweet roll marzipan marshmallow toffee brownie brownie candy tootsie roll. Chocolate cake gingerbread tootsie roll oat cake Product chocolate bar cookie dragée brownie. Lollipop cotton candy cake bear claw oat cake. Dragée candy canes dessert tart. Marzipan dragée gummies lollipop jujubes chocolate bar candy canes. Icing gingerbread chupa chups cotton candy cookie sweet icing bonbon gummies. Gummies lollipop brownie biscuit danish chocolate cake. Danish powder cookie macaroon chocolate donut tart. Carrot cake dragée croissant lemon drops liquorice lemon drops cookie lollipop toffee. Carrot cake carrot cake liquorice sugar plum topping bonbon Product muffin jujubes. Jelly pastry wafer tart caramels bear claw. Tiramisu tart Product cake danish lemon drops. Brownie cupcake dragée gummies.", Category = _categoryRepository.GetCategoryById(2), ImageUrl = "dentifrice_adulte.jfif", InStock = true, ImageThumbnailUrl = "dentifrice_adulte.jfif" };
            var p2 = new Product { ProductId = 2, Name = "Dentifrice enfant", Price = 700M, ShortDescription = "Les dents de vos enfants doivent êtres soignées!", IsProductOfTheWeek = true,  LongDescription = "Icing carrot cake jelly-o cheesecake. Sweet roll marzipan marshmallow toffee brownie brownie candy tootsie roll. Chocolate cake gingerbread tootsie roll oat cake Product chocolate bar cookie dragée brownie. Lollipop cotton candy cake bear claw oat cake. Dragée candy canes dessert tart. Marzipan dragée gummies lollipop jujubes chocolate bar candy canes. Icing gingerbread chupa chups cotton candy cookie sweet icing bonbon gummies. Gummies lollipop brownie biscuit danish chocolate cake. Danish powder cookie macaroon chocolate donut tart. Carrot cake dragée croissant lemon drops liquorice lemon drops cookie lollipop toffee. Carrot cake carrot cake liquorice sugar plum topping bonbon Product muffin jujubes. Jelly pastry wafer tart caramels bear claw. Tiramisu tart Product cake danish lemon drops. Brownie cupcake dragée gummies.", Category = _categoryRepository.GetCategoryById(2), ImageUrl = "dentifrice_enfant.jfif", InStock = true, ImageThumbnailUrl = "dentifrice_enfant.jfif" };
            var p3 = new Product { ProductId = 3, Name = "Stevia: Sucre sans calorie", Price = 1500M, ShortDescription = "Sucre feuilles stevia naturelle sans calorie et pour les diabétiques", LongDescription = "Icing carrot cake jelly-o cheesecake. Sweet roll marzipan marshmallow toffee brownie brownie candy tootsie roll. Chocolate cake gingerbread tootsie roll oat cake Product chocolate bar cookie dragée brownie. Lollipop cotton candy cake bear claw oat cake. Dragée candy canes dessert tart. Marzipan dragée gummies lollipop jujubes chocolate bar candy canes. Icing gingerbread chupa chups cotton candy cookie sweet icing bonbon gummies. Gummies lollipop brownie biscuit danish chocolate cake. Danish powder cookie macaroon chocolate donut tart. Carrot cake dragée croissant lemon drops liquorice lemon drops cookie lollipop toffee. Carrot cake carrot cake liquorice sugar plum topping bonbon Product muffin jujubes. Jelly pastry wafer tart caramels bear claw. Tiramisu tart Product cake danish lemon drops. Brownie cupcake dragée gummies.", Category = _categoryRepository.GetCategoryById(1), ImageUrl = "sucre_stevia.jfif", InStock = true, IsProductOfTheWeek = false, ImageThumbnailUrl = "sucre_stevia.jfif" };

            var p4 = new Product { ProductId = 4, Name = "Thiouray Guewe VIP", Price = 2000M, ShortDescription = "Thiouraye Guewe VIP  ", IsProductOfTheWeek = true, LongDescription = "Icing carrot cake jelly-o cheesecake. Sweet roll marzipan marshmallow toffee brownie brownie candy tootsie roll. Chocolate cake gingerbread tootsie roll oat cake Product chocolate bar cookie dragée brownie. Lollipop cotton candy cake bear claw oat cake. Dragée candy canes dessert tart. Marzipan dragée gummies lollipop jujubes chocolate bar candy canes. Icing gingerbread chupa chups cotton candy cookie sweet icing bonbon gummies. Gummies lollipop brownie biscuit danish chocolate cake. Danish powder cookie macaroon chocolate donut tart. Carrot cake dragée croissant lemon drops liquorice lemon drops cookie lollipop toffee. Carrot cake carrot cake liquorice sugar plum topping bonbon Product muffin jujubes. Jelly pastry wafer tart caramels bear claw. Tiramisu tart Product cake danish lemon drops. Brownie cupcake dragée gummies.", Category = _categoryRepository.GetCategoryById(2), ImageUrl = "thiouray_Gewe_vip.jfif", InStock = true, ImageThumbnailUrl = "thiouray_Gewe_vip.jfif" };
            var p5 = new Product { ProductId = 5, Name = "Pumpkin Product", Price = 12.95M, ShortDescription = "Lorem Ipsum", LongDescription = "Icing carrot cake jelly-o cheesecake. Sweet roll marzipan marshmallow toffee brownie brownie candy tootsie roll. Chocolate cake gingerbread tootsie roll oat cake Product chocolate bar cookie dragée brownie. Lollipop cotton candy cake bear claw oat cake. Dragée candy canes dessert tart. Marzipan dragée gummies lollipop jujubes chocolate bar candy canes. Icing gingerbread chupa chups cotton candy cookie sweet icing bonbon gummies. Gummies lollipop brownie biscuit danish chocolate cake. Danish powder cookie macaroon chocolate donut tart. Carrot cake dragée croissant lemon drops liquorice lemon drops cookie lollipop toffee. Carrot cake carrot cake liquorice sugar plum topping bonbon Product muffin jujubes. Jelly pastry wafer tart caramels bear claw. Tiramisu tart Product cake danish lemon drops. Brownie cupcake dragée gummies.", Category = _categoryRepository.GetCategoryById(3), ImageUrl = ".jpg", InStock = true, ImageThumbnailUrl = "" };

            this._allProducts = new List<Product> { p1, p2, p3, p4, p5 };

        }
        public IEnumerable<Product> AllProducts
        {
            get
            {
                return this._allProducts;
            }
        }

        public IEnumerable<Product> ProductsOfTheWeek
        {
            get
            {
                return this._allProducts.Where(p => p.IsProductOfTheWeek);
            }

      
        }



            

        public Product GetProductById(int productId)
        {
            return this.AllProducts.FirstOrDefault(p => p.ProductId == productId);
        }
    }
}
