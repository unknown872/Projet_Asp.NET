﻿using Microsoft.EntityFrameworkCore;

namespace SupdeCoMaster2022Shop.Models
{
    public class CategoryRepository: ICategoryRepository
    {
        private readonly AppSupdeCoDBContext _dbContext;
        public CategoryRepository(AppSupdeCoDBContext dbcontext)
        {
            this._dbContext = dbcontext;    

        }

        public IEnumerable<Category> AllCategories
        {
            get
            {
                return _dbContext.Categories;
            }
        }

        public Category GetCategoryById(int id)
        {
            return this._dbContext.Categories.FirstOrDefault( c => c.CategoryId == id);
        }
    }
}
