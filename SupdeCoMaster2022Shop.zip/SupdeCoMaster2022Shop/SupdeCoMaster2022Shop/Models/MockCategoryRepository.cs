﻿namespace SupdeCoMaster2022Shop.Models
{
    public class MockCategoryRepository : ICategoryRepository
    {
        //On crée une list pour créer en mémoire toutes les catégories de produits
        private List<Category> _allCategories = null;
      
        public IEnumerable<Category> AllCategories
        {
            get 
            { 
                //On crée les catégories lors du premier appel, c'est à dire la liste des toutes les catégories n'est pas encore initialisée donc vide
                if (_allCategories == null)
                {
                    var c1 = new Category { CategoryId = 1, CategoryName = "Jus de fruis locaux", Description = "Nos jus de fruits Sénégalais et Africains locaux:  Bissap, Bouye, Ditakh,.." };
                    var c2 = new Category { CategoryId = 2, CategoryName = "Produits beauté/Hygiène", Description = "La beauté n'a pas de prix!" };
                    var c3 = new Category { CategoryId = 3, CategoryName = "Produits electroniques", Description = "Nos produits électroniques pour vous simplifier la vie de tous les jours" };

                    this._allCategories = new List<Category> { c1, c2, c3 };
                }

                //On retourne la liste de toutes les catégories
                return _allCategories; 
            }
        }

        /*Une autre manière de créer toutes les catégories!
        public IEnumerable<Category> AllCategoriesS =>
            new List<Category>
            {
            new Category{CategoryId=1, CategoryName="Jus de fruis locaux", Description="Nos jus de fruits Sénégalais et Africains locaux:  Bissap, Bouye, Ditakh,.."},
            new Category{CategoryId=2, CategoryName="Produits beauté/Hygiène", Description="La beauté n'a pas de prix!"},
            new Category{CategoryId=3, CategoryName="Produits electroniques", Description="Nos produits électroniques pour vous simplifier la vie de tous les jours"}
            };
        */

        public Category GetCategoryById(int id)
        {
            foreach(var category in this.AllCategories)
            {
                if (category.CategoryId == id) return category;

            }
            return null;

                //return AllCategories.FirstOrDefault(c => c.CategoryId == (id);
            
        }



    }
}
