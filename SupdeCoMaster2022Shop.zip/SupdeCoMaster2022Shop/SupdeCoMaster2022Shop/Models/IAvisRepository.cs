﻿namespace SupdeCoMaster2022Shop.Models
{
    public interface IAvisRepository
    {
        Avis AddAvis(Avis avis);
        IEnumerable<Avis> GetAllAvis();

    }
}
