﻿using System.ComponentModel.DataAnnotations;

namespace SupdeCoMaster2022Shop.Models
{
    public class Avis
    {
        public int AvisId { get; set; }

        [MaxLength(100)]
        [Required]
        public  String FirstName { get; set; }
        [MaxLength(60)]
        [Required]
        public String LastName { get; set; }
        [EmailAddress]
        public String Email { get; set; }
        [Phone]
        public String Phone { get; set; }
        [MaxLength(200)]
        [Required]
        public String Message { get; set; }

    }
}
