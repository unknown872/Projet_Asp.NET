﻿namespace SupdeCoMaster2022Shop.Models
{
    public class Product
    {
        public Product()
        {
            //this._age = 10;
        }


        public int ProductId { get; set; }
        public string Name { get; set; }

        public string ShortDescription { get; set; }
        public string LongDescription { get; set; }

        public decimal Price { get; set; }

        public bool IsProductOfTheWeek { get; set; }

        public bool InStock { get; set; }

        public string ImageUrl { get; set; }

        public string ImageThumbnailUrl { get; set; }

        public int CategoryId { get; set; }

        public Category Category { get; set; }

        //
        private int _age;

        public int Age
        {
            get
            { return this._age; }

            set
            {
                this._age = value;
            }
        }

        public int GetAge()
        {
            return this._age;
        }

        public void SetAge(int ageParam)
        {
            this._age = ageParam;
        }

    }
}
