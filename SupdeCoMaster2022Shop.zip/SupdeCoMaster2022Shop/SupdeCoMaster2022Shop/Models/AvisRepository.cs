﻿namespace SupdeCoMaster2022Shop.Models
{
    public class AvisRepository : IAvisRepository
    {

        private AppSupdeCoDBContext _dbContext;
        public AvisRepository(AppSupdeCoDBContext dbContext)
        {
            this._dbContext = dbContext;
        }
        public Avis AddAvis(Avis newAvis)
        {
            var entity = this._dbContext.Avis.Add(newAvis);
            this._dbContext.SaveChanges();

            return entity.Entity;
        }

        public IEnumerable<Avis> GetAllAvis()
        {
            return _dbContext.Avis;
        }
    }
}
